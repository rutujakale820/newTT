package com.example.timetabler;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TimetablerApplication {
    public static void main(String[] args) {
        SpringApplication.run(TimetablerApplication.class, args);
    }
}
