package com.example.timetabler.entities.enums;

public enum RoomType {
    LEC,
    TUT,
    LAB
}
