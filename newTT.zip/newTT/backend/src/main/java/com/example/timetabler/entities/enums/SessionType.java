package com.example.timetabler.entities.enums;

public enum SessionType {
    LEC,
    TUT,
    LAB,
    ELECTIVE
}
