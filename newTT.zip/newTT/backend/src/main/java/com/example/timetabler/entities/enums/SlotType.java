package com.example.timetabler.entities.enums;

public enum SlotType {
    LEC,
    LAB,
    FOOD_BREAK
}
